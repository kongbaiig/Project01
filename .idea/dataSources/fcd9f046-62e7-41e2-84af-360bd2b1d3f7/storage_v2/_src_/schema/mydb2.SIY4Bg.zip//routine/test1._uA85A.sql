create
    definer = root@localhost procedure test1(IN userId int, OUT userCount int)
begin
declare user_name varchar(20);
select name from users where id = userId into user_name;
insert into users (name) values (user_name);
select count(*) from users into userCount;
end;

