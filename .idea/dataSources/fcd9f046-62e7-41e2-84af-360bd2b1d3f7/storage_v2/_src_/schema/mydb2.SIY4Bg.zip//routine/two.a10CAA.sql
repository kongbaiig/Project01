create
    definer = root@localhost procedure two()
begin
select * from users;
end;

