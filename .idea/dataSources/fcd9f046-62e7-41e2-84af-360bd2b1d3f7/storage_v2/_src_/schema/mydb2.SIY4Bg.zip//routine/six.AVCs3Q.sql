create
    definer = root@localhost procedure six(IN num int, OUT num1 varchar(20), OUT num2 int)
begin
select name into num1 from users where sex = num;
select count(name)into num2 from users;
end;

