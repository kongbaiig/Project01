create
    definer = root@localhost procedure test()
begin
drop table if exists temp_name_age;
create temporary table temp_name_age(name varchar(20),age int);
insert into temp_name_age select name,age from users where id between 5 and 10;
select * from temp_name_age where age = 10;
drop table temp_name_age;
end;

