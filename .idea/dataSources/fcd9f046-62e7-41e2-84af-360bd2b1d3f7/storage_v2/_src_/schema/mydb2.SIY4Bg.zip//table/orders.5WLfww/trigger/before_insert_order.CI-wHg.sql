create definer = root@localhost trigger before_insert_order
    before INSERT
    on orders
    for each row
begin
select goods_num from goods where id = new.goods_id into @num;
if @num < new.goods_num then
insert into xxx values(xxx);
end if;
end;

