create
    definer = root@localhost procedure one()
begin
select * from users;
end;

