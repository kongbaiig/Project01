create definer = root@localhost trigger after_insert_order
    after INSERT
    on orders
    for each row
begin
update goods set goods_num = goods_num - new.goods_num where id = new.goods_id;
end;

