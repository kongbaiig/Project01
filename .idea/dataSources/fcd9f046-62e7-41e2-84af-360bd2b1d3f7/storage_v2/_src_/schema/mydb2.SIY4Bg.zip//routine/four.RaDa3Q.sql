create
    definer = root@localhost procedure four(IN num int)
begin
select * from user where sex=num;
end;

