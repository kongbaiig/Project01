create
    definer = root@localhost procedure three()
begin
select * from users;
select * from users where sex = 1;
insert into users values (default,'hekaijun',23,0);
select * from users;
end;

