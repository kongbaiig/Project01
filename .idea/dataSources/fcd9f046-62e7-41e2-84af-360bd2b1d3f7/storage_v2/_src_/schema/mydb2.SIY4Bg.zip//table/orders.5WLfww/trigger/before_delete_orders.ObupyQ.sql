create definer = root@localhost trigger before_delete_orders
    before DELETE
    on orders
    for each row
begin
insert into orders values(null,old.goods_id,old.goods_num+1);
end;

